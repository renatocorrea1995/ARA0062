<head>
    <style>
        h1{font-family:sans-serif;color:#333333; text-align:center;}
        a:not(.textobranco){text-decoration:none;color:#333333;}
        a{text-decoration:none; color:white; font-family:sans-serif;}
        #voltar{
            text-align:center; 
            background-color:#ff0050; 
            font-weight:bold; 
            padding:1rem;
            color:white;
        }
    </style>
</head>
<?php

include_once "../servico/Bd.php";

$erro_senha = $erro_nome = "";

$title=$_POST['titulo'];
$corpo=$_POST['corpo'];

if(empty(trim($_POST["titulo"]))){
       echo $erro_nome = "<h1>Por favor, insira um titulo</h1>";
}
else if(empty(trim($_POST["corpo"]))){
       echo $erro_senha = "<h1>Por favor, escreva algo.</h1>";
}
else if (isset($_GET["id"])) { //atualiza
    $id = $_GET["id"];
    $sql = "update `Blog` set titulo='$login', corpo='$senha' where `Blog`.id='$id' ";
    
}

else{
       $sql = "INSERT INTO `Blog` (`id`, `titulo`, `corpo`) VALUES (NULL, '$title', '$corpo')";    
       echo "<h1>Postagem publicada com sucesso.</h1>";

       $bd = new Bd();
       $contador = $bd->exec($sql);
}

?>
<div class="container">
  <div class="row">
    <div id="voltar" class="col-sm">
      <a class="textobranco" style:"color:white;" href="./ConsultaUsuario.php">Voltar</a>
    </div>
  </div>
</div>


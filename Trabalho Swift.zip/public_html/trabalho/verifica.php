<?php
session_start();

$login=$_POST["login"];
$senha=$_POST["senha"];


include("bd2.php");
   
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $myusername = mysqli_real_escape_string($db,$_POST['login']);
      $mypassword = mysqli_real_escape_string($db,$_POST['senha']); 
      
      $sql = "SELECT usuario, senha FROM Usuario WHERE usuario = '$myusername' and senha = '$mypassword'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) {
         $_SESSION['autenticado'] = true;
         echo "<h1>Bem-vindo, $myusername</h1>";
         $html ="<html>
        <head><title>Tela de verificação </title></head>
        <body>
         <script>
         window.location.replace('menu.php');
         </script>
        </boyd>
    </html>";    
      }else {
         session_destroy();
         $html ="
<html>
    <head><title>Tela de verificação </title></head>
    <body>
        <h1>O login ou senha é inválido</h1>
    </boyd>
</html>

";
      }
      echo $html;
   }
?>